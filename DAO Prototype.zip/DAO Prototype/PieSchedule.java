package com.purplemcshortshort.cs191_timepies;

import java.util.*;

public class PieSchedule {
	private String startTime;
	private String endTime;
	private String remTime;
	private ArrayList<Slice> slices;
	
	public PieSchedule(){
		slices = new ArrayList<Slice>();
	}
	
	public String getStartTime(){
		return startTime;
	}
	
	public String getEndTime(){
		return endTime;
	}
	
	public String getRemTime(){
		return remTime;
	}
	
	public Slice getSlice(int i){
		return slices.get(i);
	}
	
	public void addSlice(Slice s){
		slices.add(s);
	}
	
	public void setStartTime(String st){
		startTime = st;
	}
	
	public void setEndTime(String et){
		endTime = et;
	}
	
	public void setRemTime(String rt){
		remTime = rt;
	}
	
	public int getSize(){
		return slices.size();
	}
	
	public void deleteSlice(int i){
		slices.remove(i);
	}
}
