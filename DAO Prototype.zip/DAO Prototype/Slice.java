package com.purplemcshortshort.cs191_timepies;

public class Slice{
	private float startAngle;
	private float sweepAngle;
	private int color;
	private String remTime;
	private Task task;
	
	public Slice(float sta, float swa, int c, String rt, Task t){
		startAngle = sta;
		sweepAngle = swa;
		color = c;
		remTime = rt;
		task = t;
	}
	
	public float getStartAngle(){
		return startAngle;
	}
	
	public float getSweepAngle(){
		return sweepAngle;
	}
	
	public int getColor(){
		return color;
	}
	
	public String getRemTime(){
		return remTime;
	}
	
	public Task getTask(){
		return task;
	}
	
	public void setStartAngle(float sta){
		startAngle = sta;
	}
	
	public void setSweepAngle(float swa){
		sweepAngle = swa;
	}
	
	public void setRemTime(String rt){
		remTime = rt;
	}
}