package com.purplemcshortshort.cs191_timepies;

public class Task{
	private String name;
	private String date;
	
	public Task(String n, String d){
		this.name = n;
		this.date = d;
	}
	
	public String getDate(){
		return date;
	}
	
	public String getName(){
		return name;
	}
	
	public void setDate(String d){
		date = d;
	}
	
	public void setName(String n){
		name = n;
	}
}