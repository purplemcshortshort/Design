package com.purplemcshortshort.cs191_timepies;
import java.util.ArrayList;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.view.View;
import android.util.AttributeSet;


public class PieUI extends View {
	
		private int circleColor;
		private Paint circlePaint;
		private RectF oval = new RectF();
		
		private ArrayList<SliceUI> slices = new ArrayList<SliceUI>();
		
	public PieUI(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	
	public PieUI(Context context, AttributeSet attrs){
	    super(context, attrs);
	    
	  //paint object for drawing in onDraw
	    circlePaint = new Paint();
	    
	  //get the attributes specified in attrs.xml using the name we included
	    TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.PieUI, 0, 0);
	    
	    try {
	        //get the color specified using the names in attrs.xml
	        circleColor = a.getInteger(R.styleable.PieUI_circleColor, 0);//0 is default
	        
	    } finally {
	        a.recycle();
	    }
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
	    //draw the View
		//get half of the width and height as we are working with a circle
		int centerX = this.getMeasuredWidth()/2;
		int centerY = this.getMeasuredHeight()/2+65;
		
		//get the radius as half of the width or height, whichever is smaller
		//subtract fifteen so that it has some space around it
		int radius = 0;
		if(centerX>centerY)
		    radius=centerY-15;
		else
		    radius=centerX-15;
		oval.set(centerX-radius, centerY-radius, centerX+radius, centerY+radius);
		
		//draw this if pie is empty
		if(slices.size() == 0) {
		}
		else {	
			circlePaint.setStyle(Style.FILL);
			//draw slices here if pie is not empty
			for (SliceUI s : slices) {
                circlePaint.setColor(s.sliceColor);
                canvas.drawArc(oval, s.startAngle, s.sweepAngle, true, circlePaint);
            }
		}
	}
	
	private class SliceUI {
        public int sliceColor;
        public float startAngle;
        public float sweepAngle;
        
        public SliceUI(int c, float t, float w){
        	sliceColor = c;
        	startAngle = t;
        	sweepAngle = w;
        }
    }
	
	public void modify(PieSchedule ps){
		while(slices.size()>0)
			slices.remove(0);
		int size = ps.getSize();
		for(int i = 0; i < size; i++){
			Slice s = ps.getSlice(i);
			slices.add(new SliceUI(s.getColor(),s.getStartAngle(),s.getSweepAngle()));
		}
		invalidate();	
	}
}
