package com.purplemcshortshort.cs191_timepies;

import java.util.*;
import android.content.Context;

public class PieScheduleController {
	//create PieSchedule from Source File
	public static void createPieSchedule(PieSchedule pieSchedule, Context context){
		PieScheduleDao.read(pieSchedule, context);
	}
	
	// reset PieSchedule and save state to source file
	public static void reset(PieSchedule pieSchedule, Context context){
		//reset the times
		pieSchedule.setStartTime("00:00:00");
		pieSchedule.setEndTime("00:00:00");
		pieSchedule.setRemTime("00:00:00");
		// delete all slices/tasks 
		while(pieSchedule.getSize()>0)
			pieSchedule.deleteSlice(0);
		// modify source file
		PieScheduleDao.write(pieSchedule, context);
	}
}