package com.purplemcshortshort.cs191_timepies;

import java.util.*;
import java.io.*;
import android.content.Context;

public class PieScheduleDao {
	
	public static void read(PieSchedule pieSchedule, Context context){
		// get start, end, remaining times from first line of source file
		pieSchedule.setStartTime("12:40:00");
		pieSchedule.setEndTime("19:15:00");
		pieSchedule.setRemTime("05:32:46");
		// get slices from the succeeding lines, one slice per line
		pieSchedule.addSlice(new Slice(10, 20, -4179669, "00:20:56", new Task("CS135 PS", "09-13-14")));
		pieSchedule.addSlice(new Slice(30, 90, -6596170, "00:20:56", new Task("CS135 LE", "09-13-14")));
		pieSchedule.addSlice(new Slice(120, 50, -4340793, "00:20:56", new Task("CS145 PS", "")));
		pieSchedule.addSlice(new Slice(170, 70, -812014, "00:20:56", new Task("sleep", "")));
		pieSchedule.addSlice(new Slice(240, 30, -2927616, "00:20:56", new Task("finish 165", "")));
		pieSchedule.addSlice(new Slice(350, 20, -9000523, "00:20:56", new Task("make pubmat", "09-13-14")));
	}
	
	public static void write(PieSchedule pieSchedule, Context context){
		try {
      	  FileOutputStream fou = context.openFileOutput("PieScheduleSource.txt", Context.MODE_WORLD_READABLE);
      	  OutputStreamWriter osw = new OutputStreamWriter(fou);
      	  try{
      		// write start, end, remaining times to source file's first line
      		String startTime = pieSchedule.getStartTime();
			String endTime = pieSchedule.getEndTime();
			String remTime = pieSchedule.getRemTime();
			osw.write(startTime+","+endTime+","+remTime+"\n");
			
			// write slices to the succeeding lines, one slice per line
			int size = pieSchedule.getSize();
			for(int i = 0; i<size; i++){
				Slice s = pieSchedule.getSlice(i);
				Task t = s.getTask();
				osw.write(Integer.toString(s.getColor())+","+Float.toString(s.getStartAngle())+","+Float.toString(s.getSweepAngle())+","+s.getRemTime()+","+t.getName()+","+t.getDate()+"\n");
			}
      		  
      		  osw.flush();
      		  osw.close();
      		  
      	  }catch(IOException e){
      		  e.printStackTrace();
      	  }
      	}catch(FileNotFoundException e){
      		e.printStackTrace();
      	}
		
		readTesting(pieSchedule, context);
	}
	
	public static void readTesting(PieSchedule pieSchedule, Context context){
		try{
			FileInputStream fis = context.openFileInput("PieScheduleSource.txt");
			InputStreamReader isr = new InputStreamReader(fis);
			int line;
			try{
				while((line = isr.read())> -1){
					System.out.print((char)line);
				}
				
			}catch(IOException e){
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
	}
	
}