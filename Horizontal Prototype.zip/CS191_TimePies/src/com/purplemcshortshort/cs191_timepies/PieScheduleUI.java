package com.purplemcshortshort.cs191_timepies;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PieScheduleUI extends Activity {
	
	private boolean isEmpty;
	private Context context;
	private Button resetButton;
	private TextView textView;
	private Typeface font;
	private View timerView;
	private TextView timerValue;
	
    private PieSchedule pieSchedule;
	private PieUI pie;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Resources res = getResources();
		setContentView(R.layout.activity_main);
		context = this;
		
		//Sets the header text font to circledfont.ttf
		textView = (TextView) findViewById(R.id.headerTextView);
		font = Typeface.createFromAsset(getAssets(), "font/circledfont.ttf");
		textView.setTypeface(font, Typeface.BOLD);
		
        //initialize reset button and create a clock listener to check if button gets clicked
		resetButton = (Button) findViewById(R.id.resetButton);
        setButtonOnClickListeners();
        
        //init pie schedule, create from source file
        pieSchedule = new PieSchedule();
        PieScheduleController.createPieSchedule(pieSchedule, context);
        
        //initialize pieUI
        pie = (PieUI) this.findViewById(R.id.PieSchedule);
        pie.modify(pieSchedule);
		
        //initial timer value upon open 
        timerValue = (TextView)findViewById(R.id.timerView);
		timerValue.setText(pieSchedule.getRemTime()); //dito ilalagay upon read ng source file
		
		if(pieSchedule.getSize() == 0)
			isEmpty = true;
		else
			isEmpty = false;
	}
	
	private void setButtonOnClickListeners(){
		
    	if(isEmpty){
    		resetButton.setOnClickListener(new Button.OnClickListener(){
        		@Override
    			public void onClick(View v) {
    
        			AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    builder1.setMessage("Pie is empty");
                    builder1.setCancelable(true);
                    builder1.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
        			
    			}
        	});
    	}
    	else{
    		resetButton.setOnClickListener(new Button.OnClickListener(){
        		public void onClick(View v) {
    			
        			AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    builder1.setMessage("Are you sure you want to reset the pie?");
                    builder1.setCancelable(true);
                    builder1.setPositiveButton("Reset",
                            new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        	
                        	//set pie to be empty
                        	PieScheduleController.reset(pieSchedule, context);
                        	pie.modify(pieSchedule);
                        	isEmpty = true;
                        	
                        	resetButton = (Button) findViewById(R.id.resetButton);
                            setButtonOnClickListeners();
                        	dialog.cancel();
                        	
                        	//change value of counter/timer to 00:00:00
                        	timerValue = (TextView)findViewById(R.id.timerView);
                    		timerValue.setText(pieSchedule.getRemTime());
                    		timerValue.invalidate();
                        }
                    });
                    builder1.setNegativeButton("Cancel",
                            new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
        			
    			}
        	});	
    	}	
    }
}